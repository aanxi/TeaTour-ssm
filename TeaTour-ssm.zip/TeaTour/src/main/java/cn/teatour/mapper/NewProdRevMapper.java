package cn.teatour.mapper;

import cn.teatour.pojo.NewProdRev;
import cn.teatour.pojo.NewProdRevExample;
import java.util.List;

public interface NewProdRevMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(NewProdRev record);

    int insertSelective(NewProdRev record);

    List<NewProdRev> selectByExample(NewProdRevExample example);

    NewProdRev selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(NewProdRev record);

    int updateByPrimaryKey(NewProdRev record);
}