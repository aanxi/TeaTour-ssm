package cn.teatour.mapper;

import cn.teatour.pojo.NewProdCate;
import cn.teatour.pojo.NewProdCateExample;
import java.util.List;

public interface NewProdCateMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(NewProdCate record);

    int insertSelective(NewProdCate record);

    List<NewProdCate> selectByExample(NewProdCateExample example);

    NewProdCate selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(NewProdCate record);

    int updateByPrimaryKey(NewProdCate record);
}