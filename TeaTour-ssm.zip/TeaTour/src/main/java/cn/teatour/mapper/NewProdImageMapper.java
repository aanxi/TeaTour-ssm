package cn.teatour.mapper;

import cn.teatour.pojo.NewProdImage;
import cn.teatour.pojo.NewProdImageExample;
import java.util.List;

public interface NewProdImageMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(NewProdImage record);

    int insertSelective(NewProdImage record);

    List<NewProdImage> selectByExample(NewProdImageExample example);

    NewProdImage selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(NewProdImage record);

    int updateByPrimaryKey(NewProdImage record);
}