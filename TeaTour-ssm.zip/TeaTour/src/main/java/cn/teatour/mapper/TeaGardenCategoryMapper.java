package cn.teatour.mapper;

import cn.teatour.pojo.TeaGardenCategory;
import cn.teatour.pojo.TeaGardenCategoryExample;
import java.util.List;

public interface TeaGardenCategoryMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TeaGardenCategory record);

    int insertSelective(TeaGardenCategory record);

    List<TeaGardenCategory> selectByExample(TeaGardenCategoryExample example);

    TeaGardenCategory selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TeaGardenCategory record);

    int updateByPrimaryKey(TeaGardenCategory record);
}