package cn.teatour.mapper;

import cn.teatour.pojo.TeaGardenReview;
import cn.teatour.pojo.TeaGardenReviewExample;
import java.util.List;

public interface TeaGardenReviewMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TeaGardenReview record);

    int insertSelective(TeaGardenReview record);

    List<TeaGardenReview> selectByExample(TeaGardenReviewExample example);

    TeaGardenReview selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TeaGardenReview record);

    int updateByPrimaryKey(TeaGardenReview record);
}