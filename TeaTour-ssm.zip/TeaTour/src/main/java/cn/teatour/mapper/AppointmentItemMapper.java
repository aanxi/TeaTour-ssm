package cn.teatour.mapper;

import cn.teatour.pojo.AppointmentItem;
import cn.teatour.pojo.AppointmentItemExample;
import java.util.List;

public interface AppointmentItemMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(AppointmentItem record);

    int insertSelective(AppointmentItem record);

    List<AppointmentItem> selectByExample(AppointmentItemExample example);

    AppointmentItem selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(AppointmentItem record);

    int updateByPrimaryKey(AppointmentItem record);
}