package cn.teatour.mapper;

import cn.teatour.pojo.TeaGardenImage;
import cn.teatour.pojo.TeaGardenImageExample;
import java.util.List;

public interface TeaGardenImageMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TeaGardenImage record);

    int insertSelective(TeaGardenImage record);

    List<TeaGardenImage> selectByExample(TeaGardenImageExample example);

    TeaGardenImage selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TeaGardenImage record);

    int updateByPrimaryKey(TeaGardenImage record);
}