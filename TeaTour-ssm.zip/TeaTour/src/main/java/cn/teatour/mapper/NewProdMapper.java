package cn.teatour.mapper;

import cn.teatour.pojo.NewProd;
import cn.teatour.pojo.NewProdExample;
import java.util.List;

public interface NewProdMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(NewProd record);

    int insertSelective(NewProd record);

    List<NewProd> selectByExample(NewProdExample example);

    NewProd selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(NewProd record);

    int updateByPrimaryKey(NewProd record);
}