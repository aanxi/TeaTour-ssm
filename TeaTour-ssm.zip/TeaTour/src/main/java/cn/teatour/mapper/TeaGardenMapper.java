package cn.teatour.mapper;

import cn.teatour.pojo.TeaGarden;
import cn.teatour.pojo.TeaGardenExample;
import java.util.List;

public interface TeaGardenMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TeaGarden record);

    int insertSelective(TeaGarden record);

    List<TeaGarden> selectByExample(TeaGardenExample example);

    TeaGarden selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TeaGarden record);

    int updateByPrimaryKey(TeaGarden record);
}