package cn.teatour.pojo;

public class TeaGardenImage {
    private Integer id;

    private Integer teaGarden_id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getTeaGarden_id() {
        return teaGarden_id;
    }

    public void setTeaGarden_id(Integer teaGarden_id) {
        this.teaGarden_id = teaGarden_id;
    }
}