package cn.teatour.pojo;

public class NewProd {
	private Integer id;

	private String name;

	private String sub_title;//具体描述

	private String price;

//	private Integer sale;
//
//	private Integer stock;

	private Integer newProdCate_id;//状态，待投票/已上线/未上线

	private Integer newProdRevCount;//已评价人数
	
	private Integer user_id;

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name == null ? null : name.trim();
	}

	public String getSub_title() {
		return sub_title;
	}

	public void setSub_title(String sub_title) {
		this.sub_title = sub_title == null ? null : sub_title.trim();
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

//	public Integer getSale() {
//		return sale;
//	}
//
//	public void setSale(Integer sale) {
//		this.sale = sale;
//	}
//
//	public Integer getStock() {
//		return stock;
//	}
//
//	public void setStock(Integer stock) {
//		this.stock = stock;
//	}

	public Integer getNewProdCate_id() {
		return newProdCate_id;
	}

	public void setNewProdCate_id(Integer newProdCate_id) {
		this.newProdCate_id = newProdCate_id;
	}

	public Integer getNewProdRevCount() {
		return newProdRevCount;
	}

	public void setNewProdRevCount(Integer newProdRevCount) {
		this.newProdRevCount = newProdRevCount;
	}

//	public Integer getSaleXNewProdRevCount() {
//		return this.newProdRevCount * this.sale;
//	}
}