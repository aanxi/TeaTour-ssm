package cn.teatour.pojo;

public class AppointmentItem {
    private Integer id;

    private Integer teaGarden_id;

    private Integer appointment_id;

    private Integer user_id;

    private Integer number;

    private TeaGarden teaGarden;

    public TeaGarden getTeaGarden() {
        return teaGarden;
    }

    public void setTeaGarden(TeaGarden teaGarden) {
        this.teaGarden = teaGarden;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getTeaGarden_id() {
        return teaGarden_id;
    }

    public void setTeaGarden_id(Integer teaGarden_id) {
        this.teaGarden_id = teaGarden_id;
    }

    public Integer getAppointment_id() {
        return appointment_id;
    }

    public void setAppointment_id(Integer appointment_id) {
        this.appointment_id = appointment_id;
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }
}