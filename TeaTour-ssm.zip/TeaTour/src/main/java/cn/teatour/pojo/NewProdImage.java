package cn.teatour.pojo;

public class NewProdImage {
    private Integer id;

    private Integer newProd_id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getNewProd_id() {
        return newProd_id;
    }

    public void setNewProd_id(Integer newProd_id) {
        this.newProd_id = newProd_id;
    }
}