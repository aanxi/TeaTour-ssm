package cn.teatour.pojo;

import java.util.Date;

public class NewProdRev {
    private Integer id;

    private String content;

    private Integer user_id;

    private Integer newProd_id;

    private Date createDate;

    private User user;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public Integer getNewProd_id() {
        return newProd_id;
    }

    public void setNewProd_id(Integer newProd_id) {
        this.newProd_id = newProd_id;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}