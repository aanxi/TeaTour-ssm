package cn.teatour.pojo;

public class TeaGarden {
	private Integer id;

	private String name;

	private String sub_title;

	private Float price;

	private Integer sale;

	private Integer stock;

	private Integer teaGardenCategory_id;

	private Integer teaGardenReviewCount;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name == null ? null : name.trim();
	}

	public String getSub_title() {
		return sub_title;
	}

	public void setSub_title(String sub_title) {
		this.sub_title = sub_title == null ? null : sub_title.trim();
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Integer getSale() {
		return sale;
	}

	public void setSale(Integer sale) {
		this.sale = sale;
	}

	public Integer getStock() {
		return stock;
	}

	public void setStock(Integer stock) {
		this.stock = stock;
	}

	public Integer getTeaGardenCategory_id() {
		return teaGardenCategory_id;
	}

	public void setTeaGardenCategory_id(Integer teaGardenCategory_id) {
		this.teaGardenCategory_id = teaGardenCategory_id;
	}

	public Integer getTeaGardenReviewCount() {
		return teaGardenReviewCount;
	}

	public void setTeaGardenReviewCount(Integer teaGardenReviewCount) {
		this.teaGardenReviewCount = teaGardenReviewCount;
	}

	public Integer getSaleXTeaGardenReviewCount() {
		return this.teaGardenReviewCount * this.sale;
	}
}