package cn.teatour.pojo;

import java.util.List;

public class NewProdCate {
    private Integer id;

    private String name;

    private List<NewProd> newProds;

    private List<List<NewProd>> newProdByRow;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public List<NewProd> getNewProds() {
        return newProds;
    }

    public void setNewProds(List<NewProd> newProds) {
        this.newProds = newProds;
    }

    public List<List<NewProd>> getNewProdByRow() {
        return newProdByRow;
    }

    public void setNewProdByRow(List<List<NewProd>> newProdByRow) {
        this.newProdByRow = newProdByRow;
    }
}