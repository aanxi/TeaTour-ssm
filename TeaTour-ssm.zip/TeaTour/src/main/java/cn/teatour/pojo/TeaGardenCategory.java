package cn.teatour.pojo;

import java.util.List;

public class TeaGardenCategory {
    private Integer id;

    private String name;

    private List<TeaGarden> teaGardens;

    private List<List<TeaGarden>> teaGardenByRow;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public List<TeaGarden> getTeaGardens() {
        return teaGardens;
    }

    public void setTeaGardens(List<TeaGarden> teaGardens) {
        this.teaGardens = teaGardens;
    }

    public List<List<TeaGarden>> getTeaGardenByRow() {
        return teaGardenByRow;
    }

    public void setTeaGardenByRow(List<List<TeaGarden>> teaGardenByRow) {
        this.teaGardenByRow = teaGardenByRow;
    }
}