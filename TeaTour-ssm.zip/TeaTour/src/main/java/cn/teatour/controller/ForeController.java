package cn.teatour.controller;

import cn.teatour.pojo.*;
import cn.teatour.service.*;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 前台控制器
 *
 * @author: @zj
 * @create: 2018-04-29-下午 14:45
 */
@Controller
@RequestMapping("")
public class ForeController {

	@Autowired
	CategoryService categoryService;

	@Autowired
	ProductService productService;

	@Autowired
	PropertyValueService propertyValueService;

	@Autowired
	ReviewService reviewService;

	@Autowired
	UserService userService;

	@Autowired
	OrderItemService orderItemService;

	@Autowired
	OrderService orderService;
	
	@Autowired
	TeaGardenService teaGardenService;

	@Autowired
	TeaGardenReviewService teaGardenReviewService;


	@Autowired
	AppointmentItemService appointmentItemService;

	@Autowired
	AppointmentService appointmentService;
	
	@Autowired
	TeaGardenCategoryService teaGardenCategoryService;
	
	@Autowired
	NewProdCateService newProdCateService;

	@Autowired
	NewProdService newProdService;

	@Autowired
	NewProdRevService newProdRevService;


	/**
	 * 首页访问方法，给首页的JSP页面添加以下数据：
	 *
	 * @param model
	 * @return
	 */
	@RequestMapping("home")
	public String home(Model model) {
		List<Category> categories = categoryService.list();
		productService.fill(categories);
		productService.fillByRow(categories);

		model.addAttribute("categories", categories);

		return "index";
	}

	@RequestMapping("/showProduct")
	public String showProduct(Model model, Integer product_id) {
		Product product = productService.get(product_id);
		productService.setReviewCount(product);
		model.addAttribute("product", product);
		List<PropertyValue> propertyValues = propertyValueService.listByProductId(product_id);
		model.addAttribute("propertyValues", propertyValues);
		List<Review> reviews = reviewService.listByProductId(product_id);
		model.addAttribute("reviews", reviews);
		return "product";
	}
	

	@RequestMapping("/showAllProduct")
	public String showAllProduct(Model model) {
		List<Category> categories = categoryService.list();
		productService.fill(categories);
		productService.fillByRow(categories);
		model.addAttribute("categories", categories);

		return "allProduct";
	}
	
	
//	@RequestMapping("/showFirstProduct")
//	public String showFirstProduct(Model model, Integer product_id) {
//		PageHelper.offsetPage(0, 20);
//		List<Product> products = productService.list(1);
//		for (Product product : products) {
//			product.setReviewCount(reviewService.getCount(product.getId()));
//		}
//		model.addAttribute("products", products);
//		return "searchResult";
//	}
//
//	@RequestMapping("/showSecondProduct")
//	public String showSecondProduct(Model model, Integer product_id) {
//		PageHelper.offsetPage(0, 20);
//		List<Product> products = productService.list(2);
//		for (Product product : products) {
//			product.setReviewCount(reviewService.getCount(product.getId()));
//		}
//		model.addAttribute("products", products);
//		return "searchResult";
//	}
	
	@RequestMapping("/searchProduct")
	public String searchProduct(Model model, String keyword) {

		PageHelper.offsetPage(0, 20);
		List<Product> products = productService.search(keyword);
		for (Product product : products) {
			product.setReviewCount(reviewService.getCount(product.getId()));
		}
		model.addAttribute("products", products);
		return "searchResult";
	}
	


	@RequestMapping("sortProduct")
	public String sortProduct(Model model, String sort, String keyword) {
		List<Product> products = productService.search(keyword);
		for (Product product : products) {
			product.setReviewCount(reviewService.getCount(product.getId()));
		}
		if (null != sort) {
			switch (sort) {
				case "all":
					Collections.sort(products, Comparator.comparing(Product::getSaleXReviewCount));
					break;
				case "reviewCount":
					Collections.sort(products, Comparator.comparing(Product::getReviewCount));
					break;
				case "date":
//					Collections.sort(products, comparing(Product::get));
					break;
				case "sale":
					Collections.sort(products, Comparator.comparing(Product::getSale));
					break;
				case "price":
					Collections.sort(products, Comparator.comparing(Product::getPrice));
					break;
			}
		}
		model.addAttribute("products", products);

		return "searchResult";
	}

	@RequestMapping("/login")
	public String login(Model model,
						@RequestParam("name") String name,
						@RequestParam("password") String password,
						HttpSession session) {
		User user = userService.get(name, password);
		if (null == user) {
			model.addAttribute("msg", "账号密码错误");
			return "loginPage";
		}
		session.setAttribute("user", user);
		return "redirect:home";
	}

	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.removeAttribute("user");
		return "redirect:home";
	}

	@RequestMapping("/register")
	public String register(Model model, User user) {
		String name = user.getName();
		boolean exist = userService.isExist(name);

		if (exist) {
			String msg = "用户名已经被占用，不能使用";
			model.addAttribute("msg", msg);
			model.addAttribute("username", user.getName());
			return "registerPage";
		}
		userService.add(user);

		return "redirect:registerSuccessPage";
	}

	/**
	 * 立即购买（即新增OrderItem项）需要考虑以下两种情况：
	 * 1.如果这个产品已经存在于购物车中，那么只需要相应的调整数量就可以了
	 * 2.如果不存在对应的OrderItem项，那么就新增一个订单项（OrderItem）
	 * - 前提条件：已经登录
	 *
	 * @param product_id 产品的ID
	 * @param number     购买的数量
	 * @param session    session用于获取user信息
	 * @return
	 */
	@RequestMapping("/buyone")
	public String buyone(Integer product_id, Integer number, HttpSession session) {
		Product product = productService.get(product_id);
		int orderItemId = 0;

		User user = (User) session.getAttribute("user");
		boolean found = false;
		
		List<OrderItem> orderItems = orderItemService.listByUserId(user.getId());
		for (OrderItem orderItem : orderItems) {
			if (orderItem.getProduct_id().intValue() == product.getId().intValue()) {
				found = true;//我加的
				orderItem.setNumber(number);
				orderItemService.update(orderItem);
				orderItemId = orderItem.getId();
				break;
			}
		}

		if (!found) {
			OrderItem orderItem = new OrderItem();
			orderItem.setUser_id(user.getId());
			orderItem.setNumber(number);
			orderItem.setProduct_id(product_id);
			orderItemService.add(orderItem);
			orderItemId = orderItem.getId();
		}

		return "redirect:buy?orderItemId=" + orderItemId;

	}

	@RequestMapping("buy")
	public String buy(Model model, String[] orderItemId, HttpSession session) {
		List<OrderItem> orderItems = new ArrayList<>();
		float total = 0;

		for (String strId : orderItemId) {
			int id = Integer.parseInt(strId);
			OrderItem oi = orderItemService.getById(id);
			total += oi.getProduct().getPrice() * oi.getNumber();
			orderItems.add(oi);
		}

		session.setAttribute("orderItems", orderItems);
		model.addAttribute("total", total);
		return "buyPage";
	}

	@RequestMapping("createOrder")
	public String createOrder(Model model, Order order, HttpSession session) {
		User user = (User) session.getAttribute("user");
		String orderCode = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
		order.setOrder_code(orderCode);
		order.setCreate_date(new Date());
		order.setUser_id(user.getId());
		order.setStatus(OrderService.waitPay);
		List<OrderItem> orderItems = (List<OrderItem>) session.getAttribute("orderItems");
		float total = orderService.add(order, orderItems);
		return "redirect:payPage?order_id=" + order.getId() + "&total=" + total;
	}

	@RequestMapping("payed")
	public String payed(int order_id, float total, Model model) {
		Order order = orderService.get(order_id);
		order.setStatus(OrderService.waitDelivery);
		order.setPay_date(new Date());
		orderService.update(order);
		model.addAttribute("o", order);
		return "payed";
	}

	/**
	 * 加入购物车方法，跟buyone()方法有些类似，但返回不同
	 * 仍然需要新增订单项OrderItem，考虑两个情况：
	 * 1.如果这个产品已经存在于购物车中，那么只需要相应的调整数量就可以了
	 * 2.如果不存在对应的OrderItem项，那么就新增一个订单项（OrderItem）
	 * - 前提条件：已经登录
	 *
	 * @param product_id
	 * @param num
	 * @param model
	 * @param session
	 * @return
	 */
	@RequestMapping("addCart")
	@ResponseBody
	public String addCart(int product_id, int num, Model model, HttpSession session) {
		Product product = productService.get(product_id);

		User user = (User) session.getAttribute("user");
		boolean found = false;
		
		List<OrderItem> orderItems = orderItemService.listByUserId(user.getId());
		for (OrderItem orderItem : orderItems) {
			if (orderItem.getProduct_id().intValue() == product.getId().intValue()) {
				found = true;//我加的
				orderItem.setNumber(orderItem.getNumber() + num);
				orderItemService.update(orderItem);
				break;
			}
		}

		if (!found) {
			OrderItem orderItem = new OrderItem();
			orderItem.setUser_id(user.getId());
			orderItem.setNumber(num);
			orderItem.setProduct_id(product_id);
			orderItemService.add(orderItem);
		}

		return "success";
	}

	/**
	 * 查看购物车方法：
	 * 1.首先通过session获取到当前的用户
	 * 2.获取这个用户关联的订单项的集合
	 *
	 * @param model
	 * @param session
	 * @return
	 */
	@RequestMapping("/cart")
	public String cart(Model model, HttpSession session) {
		User user = (User) session.getAttribute("user");
		List<OrderItem> orderItems = orderItemService.listForCart(user.getId());
		model.addAttribute("orderItems", orderItems);
		return "cart";
	}

	@RequestMapping("/checkLogin")
	@ResponseBody
	public String checkLogin(HttpSession session) {
		User user = (User) session.getAttribute("user");
		if (user != null)
			return "success";
		return "fail";
	}

	@RequestMapping("changeOrderItem")
	@ResponseBody
	public String changeOrderItem(Model model, HttpSession session, int product_id, int number) {
		User user = (User) session.getAttribute("user");
		if (null == user)
			return "fail";

		List<OrderItem> ois = orderItemService.listByUserId(user.getId());
		for (OrderItem oi : ois) {
			if (oi.getProduct().getId().intValue() == product_id) {
				oi.setNumber(number);
				orderItemService.update(oi);
				break;
			}
		}
		return "success";
	}

	@RequestMapping("deleteOrderItem")
	@ResponseBody
	public String deleteOrderItem(Model model, HttpSession session, Integer orderItemId) {
		User user = (User) session.getAttribute("user");
		if (null == user)
			return "fail";
		orderItemService.delete(orderItemId);
		return "success";
	}

	@RequestMapping("bought")
	public String bought(Model model, HttpSession session) {
		User user = (User) session.getAttribute("user");
		List<Order> orders = orderService.list(user.getId(), OrderService.delete);
		orderItemService.fill(orders);
		model.addAttribute("orders", orders);

		return "bought";
	}

	@RequestMapping("confirmPay")
	public String confirmPay(Model model, Integer order_id) {
		Order order = orderService.get(order_id);
		orderItemService.fill(order);
		model.addAttribute("order", order);
		return "confirmPay";
	}

	@RequestMapping("orderConfirmed")
	public String orderConfirmed(Model model, Integer order_id) {
		Order o = orderService.get(order_id);
		o.setStatus(OrderService.waitReview);
		o.setConfirm_date(new Date());
		orderService.update(o);
		return "orderConfirmedPage";
	}

	@RequestMapping("deleteOrder")
	@ResponseBody
	public String deleteOrder(Model model, Integer order_id) {
		Order o = orderService.get(order_id);
		o.setStatus(OrderService.delete);
		orderService.update(o);
		return "success";
	}

	@RequestMapping("review")
	public String review(Model model, Integer order_id) {
		Order order = orderService.get(order_id);
		orderItemService.fill(order);
		Product product = order.getOrderItems().get(0).getProduct();
		List<Review> reviews = reviewService.listByProductId(product.getId());
		productService.setReviewCount(product);
		model.addAttribute("product", product);
		model.addAttribute("order", order);
		model.addAttribute("reviews", reviews);
		return "reviewPage";
	}

	@RequestMapping("doreview")
	public String doreview(Model model, HttpSession session,
						   @RequestParam("order_id") Integer order_id,
						   @RequestParam("product_id") Integer product_id,
						   String content) {

		Order order = orderService.get(order_id);
		order.setStatus(OrderService.finish);
		orderService.update(order);

		User user = (User) session.getAttribute("user");
		Review review = new Review();
		review.setContent(content);
		review.setProduct_id(product_id);
		review.setCreateDate(new Date());
		review.setUser_id(user.getId());
		reviewService.add(review);

		return "redirect:review?order_id=" + order_id + "&showonly=true";
	}
	
	@RequestMapping("/showTeaGarden")
	public String showTeaGarden(Model model, Integer teaGarden_id) {
		TeaGarden teaGarden = teaGardenService.get(teaGarden_id);
		teaGardenService.setTeaGardenReviewCount(teaGarden);
		model.addAttribute("teaGarden", teaGarden);
//		List<PropertyValue> propertyValues = propertyValueService.listByTeaGardenId(teaGarden_id);
//		model.addAttribute("propertyValues", propertyValues);
//		model.addAttribute("propertyValues", propertyValues);
		List<TeaGardenReview> teaGardenReviews = teaGardenReviewService.listByTeaGardenId(teaGarden_id);
		model.addAttribute("teaGardenReviews", teaGardenReviews);
		return "teaGarden";
	}
	
	@RequestMapping("/showAllTeaGarden")
	public String showAllTeaGarden(Model model) {
		List<TeaGardenCategory> categories = teaGardenCategoryService.list();
		teaGardenService.fill(categories);
		teaGardenService.fillByRow(categories);
		model.addAttribute("categories", categories);

		return "allTeaGarden";
	}
	
//	
//	@RequestMapping("/searchTeaGarden")
//	public String searchTeaGarden(Model model, String keyword) {
//
//		PageHelper.offsetPage(0, 20);
//		List<TeaGarden> teaGardens = teaGardenService.search(keyword);
//		for (TeaGarden teaGarden : teaGardens) {
//			teaGarden.setTeaGardenReviewCount(teaGardenReviewService.getCount(teaGarden.getId()));
//		}
//		model.addAttribute("teaGardens", teaGardens);
//		return "searchResult";
//	}
//
//	@RequestMapping("sortTeaGarden")
//	public String sortTeaGarden(Model model, String sort, String keyword) {
//		List<TeaGarden> teaGardens = teaGardenService.search(keyword);
//		for (TeaGarden teaGarden : teaGardens) {
//			teaGarden.setTeaGardenReviewCount(teaGardenReviewService.getCount(teaGarden.getId()));
//		}
//		if (null != sort) {
//			switch (sort) {
//				case "all":
//					Collections.sort(teaGardens, Comparator.comparing(TeaGarden::getSaleXTeaGardenReviewCount));
//					break;
//				case "teaGardenReviewCount":
//					Collections.sort(teaGardens, Comparator.comparing(TeaGarden::getTeaGardenReviewCount));
//					break;
//				case "date":
////					Collections.sort(teaGardens, comparing(TeaGarden::get));
//					break;
//				case "sale":
//					Collections.sort(teaGardens, Comparator.comparing(TeaGarden::getSale));
//					break;
//				case "price":
//					Collections.sort(teaGardens, Comparator.comparing(TeaGarden::getPrice));
//					break;
//			}
//		}
//		model.addAttribute("teaGardens", teaGardens);
//
//		return "searchResult";
//	}

	/**
	 * 立即购买（即新增AppointmentItem项）需要考虑以下两种情况：
	 * 1.如果这个产品已经存在于购物车中，那么只需要相应的调整数量就可以了
	 * 2.如果不存在对应的AppointmentItem项，那么就新增一个订单项（AppointmentItem）
	 * - 前提条件：已经登录
	 *
	 * @param teaGarden_id 产品的ID
	 * @param number     购买的数量
	 * @param session    session用于获取user信息
	 * @return
	 */
	@RequestMapping("/appointone")
	public String appointone(Integer teaGarden_id, Integer number, HttpSession session) {
		TeaGarden teaGarden = teaGardenService.get(teaGarden_id);
		int appointmentItemId = 0;

		User user = (User) session.getAttribute("user");
		boolean found = false;
		
		List<AppointmentItem> appointmentItems = appointmentItemService.listByUserId(user.getId());
		for (AppointmentItem appointmentItem : appointmentItems) {
			if (appointmentItem.getTeaGarden_id().intValue() == teaGarden.getId().intValue()) {
				found = true;//我加的
				appointmentItem.setNumber(number);
				appointmentItemService.update(appointmentItem);
				appointmentItemId = appointmentItem.getId();
				break;
			}
		}

		if (!found) {
			AppointmentItem appointmentItem = new AppointmentItem();
			appointmentItem.setUser_id(user.getId());
			appointmentItem.setNumber(number);
			appointmentItem.setTeaGarden_id(teaGarden_id);
			appointmentItemService.add(appointmentItem);
			appointmentItemId = appointmentItem.getId();
		}

		return "redirect:appoint?appointmentItemId=" + appointmentItemId;
				
	}

	@RequestMapping("appoint")
	public String appoint(Model model, String[] appointmentItemId, HttpSession session) {
		List<AppointmentItem> appointmentItems = new ArrayList<>();
		float total = 0;

		for (String strId : appointmentItemId) {
			int id = Integer.parseInt(strId);
			AppointmentItem oi = appointmentItemService.getById(id);
			total += oi.getTeaGarden().getPrice() * oi.getNumber();
			appointmentItems.add(oi);
		}

		session.setAttribute("appointmentItems", appointmentItems);
		model.addAttribute("total", total);
		return "appointPage";
	}

	@RequestMapping("createAppointment")
	public String createAppointment(Model model, Appointment appointment, HttpSession session) {
		User user = (User) session.getAttribute("user");
		String appointmentCode = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
		appointment.setAppointment_code(appointmentCode);
		appointment.setCreate_date(new Date());
		appointment.setUser_id(user.getId());
		appointment.setStatus(AppointmentService.waitPay);
		List<AppointmentItem> appointmentItems = (List<AppointmentItem>) session.getAttribute("appointmentItems");
		float total = appointmentService.add(appointment, appointmentItems);
		return "redirect:teaGardenPayPage?appointment_id=" + appointment.getId() + "&total=" + total;
	}

	@RequestMapping("teaGardenPayed")
	public String teaGardenPayed(int appointment_id, float total, Model model) {
		Appointment appointment = appointmentService.get(appointment_id);
		appointment.setStatus(AppointmentService.waitDelivery);
		appointment.setPay_date(new Date());
		appointmentService.update(appointment);
		model.addAttribute("o", appointment);
		return "teaGardenPayed";
	}

	/**
	 * 加入购物车方法，跟appointone()方法有些类似，但返回不同
	 * 仍然需要新增订单项AppointmentItem，考虑两个情况：
	 * 1.如果这个产品已经存在于购物车中，那么只需要相应的调整数量就可以了
	 * 2.如果不存在对应的AppointmentItem项，那么就新增一个订单项（AppointmentItem）
	 * - 前提条件：已经登录
	 *
	 * @param teaGarden_id
	 * @param num
	 * @param model
	 * @param session
	 * @return
	 */

	@RequestMapping("changeAppointmentItem")
	@ResponseBody
	public String changeAppointmentItem(Model model, HttpSession session, int teaGarden_id, int number) {
		User user = (User) session.getAttribute("user");
		if (null == user)
			return "fail";

		List<AppointmentItem> ois = appointmentItemService.listByUserId(user.getId());
		for (AppointmentItem oi : ois) {
			if (oi.getTeaGarden().getId().intValue() == teaGarden_id) {
				oi.setNumber(number);
				appointmentItemService.update(oi);
				break;
			}
		}
		return "success";
	}

	@RequestMapping("deleteAppointmentItem")
	@ResponseBody
	public String deleteAppointmentItem(Model model, HttpSession session, Integer appointmentItemId) {
		User user = (User) session.getAttribute("user");
		if (null == user)
			return "fail";
		appointmentItemService.delete(appointmentItemId);
		return "success";
	}

	@RequestMapping("appointed")
	public String appointed(Model model, HttpSession session) {
		User user = (User) session.getAttribute("user");
		List<Appointment> appointments = appointmentService.list(user.getId(), AppointmentService.delete);
		appointmentItemService.fill(appointments);
		model.addAttribute("appointments", appointments);

		return "appointed";
	}

	@RequestMapping("confirmAppoint")
	public String confirmAppoint(Model model, Integer appointment_id) {
		Appointment appointment = appointmentService.get(appointment_id);
		appointmentItemService.fill(appointment);
		model.addAttribute("appointment", appointment);
		return "confirmAppoint";
	}

	@RequestMapping("appointmentConfirmed")
	public String appointmentConfirmed(Model model, Integer appointment_id) {
		Appointment o = appointmentService.get(appointment_id);
		o.setStatus(AppointmentService.waitTeaGardenReview);
		o.setConfirm_date(new Date());
		appointmentService.update(o);
		return "appointmentConfirmedPage";
	}

	@RequestMapping("deleteAppointment")
	@ResponseBody
	public String deleteAppointment(Model model, Integer appointment_id) {
		Appointment o = appointmentService.get(appointment_id);
		o.setStatus(AppointmentService.delete);
		appointmentService.update(o);
		return "success";
	}

	@RequestMapping("teaGardenReview")
	public String teaGardenReview(Model model, Integer appointment_id) {
		Appointment appointment = appointmentService.get(appointment_id);
		appointmentItemService.fill(appointment);
		TeaGarden teaGarden = appointment.getAppointmentItems().get(0).getTeaGarden();
		List<TeaGardenReview> teaGardenReviews = teaGardenReviewService.listByTeaGardenId(teaGarden.getId());
		teaGardenService.setTeaGardenReviewCount(teaGarden);
		model.addAttribute("teaGarden", teaGarden);
		model.addAttribute("appointment", appointment);
		model.addAttribute("teaGardenReviews", teaGardenReviews);
		return "teaGardenTeaGardenReviewPage";
	}

	@RequestMapping("doteaGardenReview")
	public String doteaGardenReview(Model model, HttpSession session,
						   @RequestParam("appointment_id") Integer appointment_id,
						   @RequestParam("teaGarden_id") Integer teaGarden_id,
						   String content) {

		Appointment appointment = appointmentService.get(appointment_id);
		appointment.setStatus(AppointmentService.finish);
		appointmentService.update(appointment);

		User user = (User) session.getAttribute("user");
		TeaGardenReview teaGardenReview = new TeaGardenReview();
		teaGardenReview.setContent(content);
		teaGardenReview.setTeaGarden_id(teaGarden_id);
		teaGardenReview.setCreateDate(new Date());
		teaGardenReview.setUser_id(user.getId());
		teaGardenReviewService.add(teaGardenReview);

		return "redirect:teaGardenReview?appointment_id=" + appointment_id + "&showonly=true";
	}
	
	@RequestMapping("newProdRev")
	public String newProdRev(Model model, Integer newProd_id) {
		NewProd newProd = newProdService.get(newProd_id);
//		orderItemService.fill(newProd);
//		NewProd newProd = newProd.getOrderItems().get(0).getNewProd();
		List<NewProdRev> newProdRevs = newProdRevService.listByNewProdId(newProd.getId());
		newProdService.setNewProdRevCount(newProd);
		model.addAttribute("newProd", newProd);
//		model.addAttribute("order", order);
		model.addAttribute("newProdRevs", newProdRevs);
		return "newProdRevPage";
	}

	@RequestMapping("donewProdRev")
	public String donewProdRev(Model model, HttpSession session,
						   @RequestParam("newProd_id") Integer newProd_id,
						   String content) {

		User user = (User) session.getAttribute("user");
		NewProdRev newProdRev = new NewProdRev();
		newProdRev.setContent(content);
		newProdRev.setNewProd_id(newProd_id);
		newProdRev.setCreateDate(new Date());
		newProdRev.setUser_id(user.getId());
		newProdRevService.add(newProdRev);

		return "redirect:newProdRev?newProd_id=" + newProd_id + "&showonly=true";
	}
	
	@RequestMapping("/showNewProd")
	public String showNewProd(Model model, Integer newProd_id) {
		NewProd newProd = newProdService.get(newProd_id);
		newProdService.setNewProdRevCount(newProd);
		model.addAttribute("newProd", newProd);
		List<NewProdRev> newProdRevs = newProdRevService.listByNewProdId(newProd_id);
		model.addAttribute("newProdRevs", newProdRevs);
		return "newProd";
	}
	
	@RequestMapping("createNewProd")
	public String createNewProd(Model model, NewProd newProd, HttpSession session) {
		User user = (User) session.getAttribute("user");
		//创建一个对象
		Random df = new Random();		 
		//引用nextInt()方法
		int id = df.nextInt(1001);
		newProd.setId(id);
		newProd.setUser_id(user.getId());
		newProd.setNewProdCate_id(1);
		newProdService.add(newProd);
		return "createPage";
	}

	
	@RequestMapping("/showAllNewProd")
	public String showAllNewProduct(Model model,Integer newProdCate_id) {
		List<NewProd> newProds = newProdService.list(1);
		newProds.addAll(newProdService.list(2));
		newProds.addAll(newProdService.list(3));
		model.addAttribute("newProds", newProds);
		return "allNewProd";
	}

}
